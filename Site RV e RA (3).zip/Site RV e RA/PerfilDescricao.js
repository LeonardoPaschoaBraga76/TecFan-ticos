function descricao1(){

    let describe = document.getElementById("des1");

    describe.innerHTML = "<h5>Olá meu nome é Victor, tenho 15 anos e sou aluno do curso de Desenvolvimento de Sistemas. Nesse projeto fiquei encarregado pelo <strong>Conteúdo e Programação</strong>. </h5>";
    describe.style.textAlign = 'initial';
    describe.style.marginRight = '10px';
    describe.style.borderRadius = '10px';
    describe.style.padding = '15px'
    describe.style.font = "normal 13pt Arial";
    describe.style.background = "#3a6d8f";
    describe.style.color = " white";

}
function descricao2(){

    let describe = document.getElementById("des2");

    describe.innerHTML = "<h5>Olá meu nome é Leonardo, tenho 15 anos e sou aluno do curso de Desenvolvimento de Sistemas. Nesse projeto fiquei encarregado pelo <strong>Conteúdo e Design</strong>. </h5>";
    describe.style.textAlign = 'initial';
    describe.style.marginRight = '10px';
    describe.style.borderRadius = '10px';
    describe.style.padding = '15px'
    describe.style.font = "normal 13pt Arial";
    describe.style.background = "#34838f";
    describe.style.color = " white";


}

function descricao4(){

    let describe = document.getElementById("des4");

    describe.innerHTML = "<h5>Olá meu nome é Lucas, tenho 15 anos e sou aluno do curso de Desenvolvimento de Sistemas. Nesse projeto fiquei encarregado pelo <strong>Conteúdo e Programação</strong>. </h5>";
    describe.style.textAlign = 'initial';
    describe.style.marginRight = '10px';
    describe.style.borderRadius = '10px';
    describe.style.padding = '15px'
    describe.style.font = "normal 13pt Arial";
    describe.style.background = "rgb(16, 104, 163)";
    describe.style.color = " white";

}

